-- Built by Olivia — https://discord.gg/ojailbreaks
-- Insira SnowHubPackage.rbxmx em Workspace; execute este código no Command Bar, fora do Play.
assert(not game:GetService("RunService"):IsRunning(), "Pare o Play antes de instalar.")
local package = workspace:FindFirstChild("SnowHubPackage")
assert(package, "Insira SnowHubPackage.rbxmx em Workspace primeiro.")
local operations = {
    {package:FindFirstChild("ReplicatedStorage"), "SnowHub", game:GetService("ReplicatedStorage")},
    {package:FindFirstChild("ServerScriptService"), "SnowHubServer", game:GetService("ServerScriptService")},
    {package:FindFirstChild("StarterPlayerScripts"), "SnowHub", game:GetService("StarterPlayer"):WaitForChild("StarterPlayerScripts")},
}
for _, operation in ipairs(operations) do
    assert(operation[1] and operation[1]:FindFirstChild(operation[2]), "Pacote incompleto: " .. operation[2])
    assert(not operation[3]:FindFirstChild(operation[2]), "Já existe " .. operation[2] .. ". Remova ou renomeie a instalação anterior antes de instalar.")
end
for _, operation in ipairs(operations) do operation[1][operation[2]].Parent = operation[3] end
package:Destroy()
print("Snow Hub instalado. Pressione Play para abrir a arena e o painel.")
