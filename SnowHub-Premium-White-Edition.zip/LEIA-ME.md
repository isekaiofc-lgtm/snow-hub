# SNOW HUB ❄ — PREMIUM WHITE EDITION

Built by Olivia — https://discord.gg/ojailbreaks

Projeto Luau para **um jogo de testes próprio no Roblox**. O cliente também é empacotado em um único arquivo para execução pelo Xeno. As funcionalidades dependem do backend instalado no mesmo jogo. O pacote não integra os sistemas privados de Your Bizarre Adventure.

## Abrir a demonstração no Studio

1. Extraia o ZIP.
2. No Roblox Studio, abra `dist/SnowHubTestPlace.rbxlx` por **File → Open from File**.
3. Pressione **Play/F5**. A arena e o painel são criados ao iniciar.
4. Use **Dashboard → Ir para a arena de testes** se o personagem estiver longe.
5. Em **Farming**, escolha uma categoria e ative a coleta. O personagem caminha com PathfindingService; a coleta ocorre somente dentro do alcance confirmado pelo servidor.
6. Em **Visual**, ligue ESP ou hitboxes. Cor e transparência são ajustáveis. As hitboxes são somente desenhos das peças reais.
7. Em **Combat**, aproxime-se de um Snow Dummy, aplique um golpe ou ative o treino. O servidor verifica alcance e obstáculos. Os números flutuantes representam o dano aplicado de fato.

O place de demonstração executa `RulesSpec` no servidor ao iniciar. A mensagem de sucesso aparece em **Output**. Os testes de contrato estão incluídos; consulte `dist/build-report.json` para distinguir verificações realizadas fora do Roblox de testes que exigem o aplicativo.

## Instalar em um projeto existente

Faça uma cópia do seu place antes da instalação.

1. Em uma área vazia do **Explorer/Workspace**, use **Insert from File** e selecione `dist/SnowHubPackage.rbxmx`.
2. Com o Play parado, abra o **Command Bar**. Cole o conteúdo de `Install-Studio.command.lua` e execute.
3. O instalador move os arquivos aos serviços corretos e para se detectar uma instalação existente.
4. Abra `ServerScriptService → SnowHubServer → ServerConfig` e configure `AllowedUserIds` quando houver outros testadores. Em experiências pertencentes a grupo, preencha essa lista, pois o grupo não concede acesso implicitamente.
5. Pressione Play. Por padrão, a demonstração nasce em `(0, 120, 0)`; ajuste `WorldOrigin` se essa área estiver ocupada.

Também é possível mapear os arquivos manualmente usando a tabela abaixo, ou sincronizar `default.project.json` com Rojo.

| Arquivo/pasta de origem | Destino no Studio | Tipo |
| --- | --- | --- |
| `src/ReplicatedStorage/SnowHub` | `ReplicatedStorage/SnowHub` | Folder |
| `Config.lua`, `Shared/Maid.lua`, `Client/*.lua` | Dentro dessa pasta, conservando subpastas | ModuleScript |
| `src/ServerScriptService/SnowHubServer` | `ServerScriptService/SnowHubServer` | Folder |
| `Main.server.lua` | `ServerScriptService/SnowHubServer/Main` | Script |
| `ServerConfig.lua`, `Rules.lua`, `DemoWorld.lua` | `ServerScriptService/SnowHubServer` | ModuleScript |
| `src/StarterPlayer/StarterPlayerScripts/SnowHub.client.lua` | `StarterPlayer/StarterPlayerScripts/SnowHub` | LocalScript |
| `tests/Rules.spec.lua` | `ServerScriptService/SnowHubServer/RulesSpec` | ModuleScript |

`Main.server.lua` deve continuar como Script dentro da pasta SnowHubServer. Não transforme a pasta inteira em um Script.

## Loader para Xeno

O arquivo `dist/loader.lua` contém a linha no formato solicitado:

```lua
loadstring(game:HttpGet("https://raw.githubusercontent.com/isekaiofc-lgtm/snow-hub/main/snowhub.lua"))()
```

**Cliente publicado:** o endereço acima aponta para `snowhub.lua` no repositório público `isekaiofc-lgtm/snow-hub`. O conteúdo remoto foi conferido contra o cliente preparado. O funcionamento dentro do Xeno depende da execução nesse aplicativo e do backend instalado no jogo. Também é possível copiar diretamente o conteúdo de `dist/snowhub.lua` no ambiente preparado.

1. Publique o jogo preparado em sua conta Roblox.
2. Autorize a conta de teste no ServerConfig; o dono de uma experiência pessoal já é autorizado por padrão.
3. Entre nesse jogo pelo aplicativo Roblox e execute o loader no Xeno.
4. Se o LocalScript de inicialização já abriu a interface, o loader encerra a sessão anterior antes de iniciar outra. Para abrir exclusivamente pelo Xeno, desabilite apenas `StarterPlayerScripts/SnowHub` antes de publicar. Mantenha o backend ativo.

O cliente único usa os serviços oficiais. Apenas a linha externa depende de `loadstring`/`HttpGet` oferecidos pelo executor. Não é necessário habilitar `LoadStringEnabled` no servidor, `HttpService.HttpEnabled` ou instalar bibliotecas no cliente. O pacote não modifica anticheat.

## Server Hop

O servidor registra sua instância pública em um MemoryStoreSortedMap com expiração. A lista inclui somente instâncias com o backend Snow Hub **do mesmo place**. O cliente confirma o destino; o servidor lê o registro novamente antes de chamar `TeleportAsync`.

O Roblox não executa teleportes durante Play no Studio. Teste esta função com o jogo publicado no aplicativo Roblox. São necessárias duas instâncias públicas ativas. Instâncias privadas/reservadas não são cadastradas por esta implementação. Falhas de API e listas vazias são exibidas explicitamente.

Referências oficiais:

- https://create.roblox.com/docs/reference/engine/classes/TeleportService
- https://create.roblox.com/docs/reference/engine/classes/MemoryStoreSortedMap
- https://create.roblox.com/docs/reference/engine/classes/CollectionService
- https://create.roblox.com/docs/reference/engine/classes/Highlight

## Adicionar seus próprios objetos de teste

Desative `CreateDemoWorld` no ServerConfig e crie `Workspace/SnowHubTestWorld`.

- **Item:** BasePart ou Model com PrimaryPart; tag `SnowHubItem`; atributos `Available = true`, `Category = "Cristais"` (ou outra categoria configurada) e `ItemId` opcional. O contador é de coletas da sessão; não existe inventário permanente neste projeto.
- **NPC:** Model dentro de SnowHubTestWorld, com tag `SnowHubNPC`, Humanoid vivo e HumanoidRootPart. O Combat Tester nunca aceita personagens de jogadores como alvo.
- **Arena:** no Folder SnowHubTestWorld, configure `SpawnCFrame` como atributo CFrame para habilitar o botão de deslocamento até a arena.

Os atributos de permissão, dano e alcance são definidos no servidor. Não envie valores de dano do cliente. Os NPCs e itens só aparecem no ESP se estiverem replicados; o cliente não pode exibir objetos ausentes devido a StreamingEnabled.

## Comportamentos e limites

- Todas as automações começam desligadas. O indicador de dano só aparece após um ataque confirmado.
- Farming e treino automático se interrompem mutuamente. O treino não aproxima o personagem sozinho: posicione-se no alcance do NPC.
- RightShift oculta/reabre; a aba ❄ permanece disponível quando minimizado. Fechar confirma e remove interface, marcações, desfoque próprio e conexões.
- Desligar todas interrompe loops e remove os visuais. Uma requisição já enviada ao servidor pode concluir antes da interrupção.
- O desfoque de fundo é opcional. O efeito de vidro da interface é composto por transparência, gradiente e bordas; não aplica um desfoque restrito a uma região da tela.
- O ESP atualiza até 48 objetos próximos a cada 0,15 segundo. As estatísticas atualizam a cada 2 segundos.
- Contadores e preferências são de sessão. Reiniciar o servidor ou sair descarta esses dados.
- Os testes fora do Roblox não comprovam renderização, navegação, teleporte ou compatibilidade com uma versão específica do Xeno. Não é possível prometer 100% sem executar nesses ambientes.

## Diagnóstico

| Mensagem/situação | Ação |
| --- | --- |
| Servidor Snow Hub não instalado | Instale o backend no mesmo jogo ou abra o place fornecido |
| Sem permissão | Ajuste AllowedUserIds no ServerConfig e publique novamente |
| Nenhum item | Confira pasta, tags, Available e categoria |
| Sem caminho disponível | Libere passagem ou ajuste o cenário; confira se o personagem não está bloqueado |
| Fora de alcance | Aproxime-se do NPC ou item; os limites são validados no servidor |
| Nenhuma outra instância | Abra outra instância pública do mesmo place e aguarde até 30 segundos |
| Sem resposta do servidor | Consulte Output; confira se Main está ativo e se os protocolos coincidem |
| Interface ausente | Consulte Output/console e use RightShift; o Xeno precisa executar o cliente Luau |

## Compilar novamente

Com Python 3, execute na pasta SnowHub:

```powershell
python tools/build.py
```

O comando recria o bundle, os XMLs para Studio e o ZIP. O código modular fica em `src`; os resultados ficam em `dist`. Não publique ServerConfig contendo dados que você prefira manter privados. A instalação aqui usa uma allowlist vazia por padrão.
