-- Built by Olivia — https://discord.gg/ojailbreaks
-- O mesmo ponto de entrada é usado no Studio e no bundle para Xeno.
return function(modules)
    local Players = game:GetService("Players")
    local RunService = game:GetService("RunService")
    if not game:IsLoaded() then game.Loaded:Wait() end
    local player = Players.LocalPlayer
    if not player then error("Snow Hub deve ser iniciado no cliente.") end
    local playerGui = player:WaitForChild("PlayerGui")
    local old = playerGui:FindFirstChild("SnowHubSession")
    if old then
        local shutdown = old:FindFirstChild("Shutdown")
        if shutdown and shutdown:IsA("BindableEvent") then shutdown:Fire(); task.wait() end
        old:Destroy()
    end
    local ctx = {alive = true, authorized = false, config = modules.Config,
        Maid = modules.Maid, modules = {}, pages = {}, stats = {}, server = {}, status = "Inicializando"}
    ctx.maid = ctx.Maid.new()
    local session = Instance.new("Folder")
    session.Name, session.Parent = "SnowHubSession", playerGui
    local shutdown = Instance.new("BindableEvent")
    shutdown.Name, shutdown.Parent = "Shutdown", session
    ctx.maid:Give(session)
    ctx.visualRoot = Instance.new("Folder")
    ctx.visualRoot.Name, ctx.visualRoot.Parent = "SnowHubClientVisuals", workspace
    ctx.maid:Give(ctx.visualRoot)
    function ctx:RequirePermission()
        if self.alive and self.authorized then return true end
        if self.ui then self.ui:Notify("Função indisponível", self.status, true) end
        return false
    end
    function ctx:SetStats(stats)
        if not self.alive or type(stats) ~= "table" then return end
        self.stats = stats
        for _, module in pairs(self.modules) do
            if module.UpdateStats then module:UpdateStats(stats) end
        end
        if self.dashboardStats then
            self.dashboardStats.Text = string.format("%d itens coletados   •   %d golpes   •   %d de dano",
                stats.items or 0, stats.hits or 0, stats.damage or 0)
        end
    end
    function ctx:StopAll(notify)
        for _, module in pairs(self.modules) do
            if module.Stop then pcall(function() module:Stop() end) end
        end
        if self.ui then
            self.ui:SetBlur(false)
            if self.blurToggle then self.blurToggle:Set(false) end
            if notify ~= false then self.ui:Notify("Funções desligadas", "Farming, visuais, treino e efeitos foram interrompidos.") end
        end
    end
    function ctx:Destroy()
        if not self.alive then return end
        self.alive = false
        self:StopAll(false)
        if self.net then self.net:Destroy() end
        self.maid:Destroy()
        if self.ui then self.ui:Destroy() end
    end
    ctx.maid:Connect(shutdown.Event, function() ctx:Destroy() end)
    local success, err = pcall(function()
        ctx.ui = modules.UI(ctx)
        local ui = ctx.ui
        ctx.maid:Connect(ui.gui.Destroying, function() ctx:Destroy() end)
        ui:StartLoading()
        ui:Progress(0.16, "Montando interface branca-neve")
        for _, page in ipairs({{"Dashboard", "❄"}, {"Farming", "📦"}, {"Visual", "👁"},
            {"Combat", "⚔"}, {"Servers", "🌐"}, {"Settings", "⚙"}}) do
            ctx.pages[page[1]] = ui:Page(page[1], page[2])
        end
        local home = ui:Section(ctx.pages.Dashboard, "Bem-vindo ao Snow Hub", "PREMIUM WHITE EDITION • PC • versão " .. ctx.config.Version)
        local connection = ui:Label(home, "Conectando ao servidor de testes...")
        ctx.dashboardStats = ui:Label(home, "0 itens coletados   •   0 golpes   •   0 de dano")
        local diagnostics = ui:Label(home, "FPS: —   •   Resposta do servidor: —")
        ui:Button(home, "Ir para a arena de testes", function()
            if not ctx:RequirePermission() then return end
            local result = ctx.net:Request("Arena")
            if ctx.alive then ui:Notify("Arena", result.ok and result.data.message or result.message, not result.ok) end
        end)
        ui:Button(home, "Desligar todas as funções", function() ctx:StopAll() end)
        local about = ui:Section(ctx.pages.Dashboard, "Ambiente preparado", "Módulos operam nos itens e NPCs criados por este projeto.")
        ui:Label(about, "RightShift mostra ou esconde o painel. Arraste a barra superior com o mouse. O botão ❄ reabre o painel minimizado.")
        for _, name in ipairs({"Farming", "Visual", "Combat", "Servers"}) do ctx.modules[name] = modules[name](ctx) end
        local settings = ui:Section(ctx.pages.Settings, "⚙ Preferências", "Configurações locais desta sessão. O painel permanece disponível para reativar funções.")
        ctx.blurToggle = ui:Toggle(settings, "Desfoque de fundo", false, function(value) ui:SetBlur(value); return true end)
        ui:Toggle(settings, "Reduzir animações", false, function(value) ui.reducedMotion = value; return true end)
        ui:Button(settings, "Desligar todas as funções", function() ctx:StopAll() end)
        ui:Button(settings, "Encerrar Snow Hub", function()
            ui:Confirm("Encerrar Snow Hub?", "A interface e todos os recursos locais serão removidos.", function() ctx:Destroy() end)
        end)
        local permission = ui:Section(ctx.pages.Settings, "Permissões e conexão", "A lista de testadores é controlada pelo ServerConfig dentro de ServerScriptService.")
        local permissionLabel = ui:Label(permission, "Verificando acesso...")
        ui:Progress(0.45, "Localizando backend Snow Hub")
        ctx.net = modules.Network(ctx)
        if not ctx.alive then ctx.net:Destroy(); return end
        local function authenticate()
            if not ctx.alive then return end
            local result = ctx.net:Request("Handshake", {protocol = ctx.config.Protocol})
            if not ctx.alive then return end
            ctx.authorized = result.ok and type(result.data) == "table" and result.data.protocol == ctx.config.Protocol
            if ctx.authorized then
                ctx.server, ctx.status = result.data, "Acesso autorizado ao ambiente de testes."
                ctx:SetStats(result.data.stats)
                ctx.modules.Combat.range = math.min(12, ctx.server.attackRange)
                ctx.modules.Servers:Connected()
            else
                ctx.status = result.message or "Versão incompatível com o servidor."
                ctx:StopAll(false)
            end
            connection.Text, permissionLabel.Text, ui.footer.Text = ctx.status, ctx.status, ctx.status
            ui:Notify(ctx.authorized and "Snow Hub conectado" or "Ambiente indisponível", ctx.status, not ctx.authorized)
        end
        ui:Button(permission, "Verificar permissões novamente", function()
            if not ctx.net.available then
                ctx.net:Destroy()
                ctx.net = modules.Network(ctx)
                ctx:AttachFeedback()
            end
            authenticate()
        end)
        function ctx:AttachFeedback()
            if self.feedbackConnection then self.feedbackConnection:Disconnect(); self.feedbackConnection = nil end
            if self.net.available then
                self.feedbackConnection = self.maid:Connect(self.net.feedback.OnClientEvent, function(event, data)
                    if not self.alive or type(data) ~= "table" then return end
                    if data.stats then self:SetStats(data.stats) end
                    if event == "Damage" then self.modules.Combat:OnDamage(data)
                    elseif event == "Error" then ui:Notify("Servidor", data.message or "Ação não concluída.", true) end
                end)
            end
        end
        ctx:AttachFeedback()
        ui:Progress(0.78, "Validando permissões no servidor")
        authenticate()
        if not ctx.alive then return end
        local frames, elapsed = 0, 0
        ctx.maid:Connect(RunService.RenderStepped, function(dt)
            frames, elapsed = frames + 1, elapsed + dt
            if elapsed >= 1 then
                diagnostics.Text = string.format("FPS: %d   •   Resposta do servidor: %d ms",
                    math.floor(frames / elapsed), ctx.net.latency)
                frames, elapsed = 0, 0
            end
        end)
        ctx.maid:Give(task.spawn(function()
            while ctx.alive do
                task.wait(2)
                if ctx.alive and ctx.authorized then
                    local result = ctx.net:Request("Stats")
                    if not ctx.alive then break end
                    if result.ok then ctx:SetStats(result.data)
                    elseif result.message and string.find(result.message, "Sem permissão", 1, true) then
                        ctx.authorized, ctx.status = false, result.message
                        ctx:StopAll(false)
                        ui:Notify("Acesso removido", result.message, true)
                    end
                end
            end
        end))
        ui:Select("Dashboard")
        ui:FinishLoading()
    end)
    if not success then
        warn("[Snow Hub] inicialização: " .. tostring(err))
        ctx:Destroy()
        error("Snow Hub interrompido: " .. tostring(err), 0)
    end
    return ctx
end
