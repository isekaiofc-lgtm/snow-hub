-- Built by Olivia — https://discord.gg/ojailbreaks
return function(ctx)
    local Players = game:GetService("Players")
    local Collection = game:GetService("CollectionService")
    local RunService = game:GetService("RunService")
    local module = {enabled = false, showRange = false, showDamage = true, range = 12,
        trainingMaid = nil, rangeMaid = nil, floats = {}}
    local ui = ctx.ui
    local card = ui:Section(ctx.pages.Combat, "⚔ Combat Tester", "Ataques de teste atingem somente NPCs autorizados. Alcance, obstáculos e dano são validados pelo servidor.")
    local targetLabel = ui:Label(card, "Alvo: nenhum NPC próximo")
    local status = ui:Label(card, "Posicione-se perto de um NPC da arena.")
    local statsLabel = ui:Label(card, "Acertos: 0   •   Dano: 0   •   NPCs derrotados: 0")
    local rangeToggle, trainToggle, damageToggle
    local function root()
        local ch = Players.LocalPlayer.Character
        local hum = ch and ch:FindFirstChildOfClass("Humanoid")
        return hum and hum.Health > 0 and ch:FindFirstChild("HumanoidRootPart") or nil
    end
    local function nearest(limit)
        local origin = root()
        local world = workspace:FindFirstChild(ctx.config.WorldName)
        if not origin or not world then return end
        local best, distance = nil, limit
        for _, npc in ipairs(Collection:GetTagged(ctx.config.NPCTag)) do
            if npc:IsA("Model") and npc:IsDescendantOf(world) then
                local hum, part = npc:FindFirstChildOfClass("Humanoid"), npc:FindFirstChild("HumanoidRootPart")
                if hum and hum.Health > 0 and part then
                    local d = (part.Position - origin.Position).Magnitude
                    if d <= distance then best, distance = npc, d end
                end
            end
        end
        return best, distance
    end
    function module:Attack(manual)
        if not ctx:RequirePermission() then return false end
        local target, distance = nearest(manual and 250 or self.range)
        if not target then status.Text = "Nenhum NPC válido no alcance selecionado."; return false end
        targetLabel.Text = target.Name .. "  |  " .. string.format("%.1f", distance) .. " studs"
        local result = ctx.net:Request("Attack", {target = target})
        if not ctx.alive then return false end
        if result.ok then
            ctx:SetStats(result.data)
            status.Text = "Golpe confirmado pelo servidor."
        else
            status.Text = result.message
            if manual then ui:Notify("Teste de golpe", result.message, true) end
        end
        return result.ok
    end
    function module:StopTraining()
        self.enabled = false
        if self.trainingMaid then self.trainingMaid:Destroy(); self.trainingMaid = nil end
        if trainToggle then trainToggle:Set(false) end
    end
    function module:StartTraining()
        if self.enabled then return true end
        if not ctx:RequirePermission() then return false end
        if ctx.modules.Farming then ctx.modules.Farming:Stop() end
        self.enabled = true
        self.trainingMaid = ctx.Maid.new()
        self.trainingMaid:Give(task.spawn(function()
            local success, err = pcall(function()
                while ctx.alive and module.enabled do
                    module:Attack(false)
                    task.wait(math.max(ctx.server.attackCooldown, 0.4) + 0.1)
                end
            end)
            if not success and ctx.alive then
                module.enabled = false
                trainToggle:Set(false)
                ui:Notify("Treino interrompido", tostring(err):sub(1, 150), true)
            end
        end))
        return true
    end
    function module:SetRangeVisible(value)
        self.showRange = value
        if self.rangeMaid then self.rangeMaid:Destroy(); self.rangeMaid = nil end
        if not value then return end
        self.rangeMaid = ctx.Maid.new()
        local sphere = self.rangeMaid:Give(ui:Create("SphereHandleAdornment", {Radius = self.range,
            AlwaysOnTop = false, Color3 = Color3.fromRGB(143, 190, 235), Transparency = 0.88, ZIndex = 0}, ctx.visualRoot))
        self.rangeMaid:Connect(RunService.Heartbeat, function()
            sphere.Adornee, sphere.Radius = root(), module.range
        end)
    end
    ui:Slider(card, "Alcance de treino (studs)", 1, 12, module.range, function(value)
        module.range = math.min(value, ctx.server and ctx.server.attackRange or 12)
    end)
    rangeToggle = ui:Toggle(card, "Exibir esfera de alcance", false, function(value)
        if value and not ctx:RequirePermission() then return false end
        module:SetRangeVisible(value); return true
    end)
    damageToggle = ui:Toggle(card, "Indicadores de dano confirmado", true, function(value)
        module.showDamage = value
        if not value then module:ClearFloats() end
        return true
    end)
    ui:Button(card, "Aplicar um golpe de teste", function() module:Attack(true) end)
    trainToggle = ui:Toggle(card, "Treino automático com NPCs", false, function(value)
        if value then return module:StartTraining() end
        module:StopTraining(); return true
    end)
    local statsCard = ui:Section(ctx.pages.Combat, "Estatísticas da sessão", "Os números vêm do servidor e são zerados ao sair da instância.")
    local dpsLabel = ui:Label(statsCard, "DPS da sessão: 0   •   Fora de alcance/obstáculo: 0")
    ui:Button(statsCard, "Zerar estatísticas da sessão", function()
        if not ctx:RequirePermission() then return end
        ui:Confirm("Zerar estatísticas?", "Coletas, dano, acertos e derrotas desta sessão voltarão a zero.", function()
            local result = ctx.net:Request("ResetStats")
            if result.ok then ctx:SetStats(result.data) else ui:Notify("Estatísticas", result.message, true) end
        end)
    end)
    function module:ClearFloats()
        for object in pairs(self.floats) do object:Destroy() end
        self.floats = {}
    end
    function module:OnDamage(data)
        if not self.showDamage or typeof(data.position) ~= "Vector3" then return end
        local count = 0
        for _ in pairs(self.floats) do count = count + 1 end
        if count >= 12 then return end
        local anchor = ui:Create("Part", {Size = Vector3.new(0.1, 0.1, 0.1), Anchored = true,
            CanCollide = false, CanQuery = false, CanTouch = false, Transparency = 1,
            Position = data.position + Vector3.new(0, 3, 0)}, ctx.visualRoot)
        self.floats[anchor] = true
        local billboard = ui:Create("BillboardGui", {Adornee = anchor, AlwaysOnTop = true, Size = UDim2.fromOffset(100, 40)}, anchor)
        local label = ui:Create("TextLabel", {Size = UDim2.fromScale(1, 1), BackgroundTransparency = 1,
            Text = "−" .. tostring(data.damage), TextColor3 = Color3.fromRGB(237, 246, 255),
            TextStrokeTransparency = 0.15, Font = Enum.Font.GothamBold, TextSize = 24}, billboard)
        ui:Tween(anchor, {Position = anchor.Position + Vector3.new(0, 3, 0)}, 0.8)
        ui:Tween(label, {TextTransparency = 1, TextStrokeTransparency = 1}, 0.9)
        task.delay(1, function() self.floats[anchor] = nil; anchor:Destroy() end)
    end
    function module:UpdateStats(stats)
        statsLabel.Text = string.format("Acertos: %d   •   Dano: %d   •   NPCs derrotados: %d", stats.hits or 0, stats.damage or 0, stats.kills or 0)
        dpsLabel.Text = string.format("DPS da sessão: %.1f   •   Fora de alcance/obstáculo: %d", (stats.damage or 0) / math.max(0.01, stats.elapsed or 1), stats.misses or 0)
    end
    function module:Stop()
        self:StopTraining(); self:SetRangeVisible(false)
        self.showDamage = false
        damageToggle:Set(false); rangeToggle:Set(false)
        self:ClearFloats()
        status.Text = "Treino e indicadores interrompidos."
    end
    module.Destroy = module.Stop
    return module
end
