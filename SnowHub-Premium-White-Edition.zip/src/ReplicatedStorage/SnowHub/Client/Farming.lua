-- Built by Olivia — https://discord.gg/ojailbreaks
return function(ctx)
    local Players = game:GetService("Players")
    local Collection = game:GetService("CollectionService")
    local Pathfinding = game:GetService("PathfindingService")
    local player = Players.LocalPlayer
    local module = {enabled = false, category = "Todos", maid = nil, generation = 0}
    local ui, page = ctx.ui, ctx.pages.Farming
    local card = ui:Section(page, "📦 Item Farm", "O personagem caminha até os itens da arena. A coleta é confirmada pelo servidor.")
    local counter = ui:Label(card, "Coletados nesta sessão: 0")
    local status = ui:Label(card, "Pronto para iniciar.")
    local toggle
    local function actor()
        local ch = player.Character
        local hum = ch and ch:FindFirstChildOfClass("Humanoid")
        local root = ch and ch:FindFirstChild("HumanoidRootPart")
        if hum and hum.Health > 0 and root then return hum, root end
    end
    local function itemPart(item)
        if item:IsA("BasePart") then return item end
        return item:IsA("Model") and (item.PrimaryPart or item:FindFirstChildWhichIsA("BasePart", true)) or nil
    end
    local function nearest(root)
        local world = workspace:FindFirstChild(ctx.config.WorldName)
        local best, distance = nil, ctx.server.farmRange
        for _, item in ipairs(Collection:GetTagged(ctx.config.ItemTag)) do
            local part = itemPart(item)
            if world and item:IsDescendantOf(world) and part and item:GetAttribute("Available") == true
                and (module.category == "Todos" or item:GetAttribute("Category") == module.category) then
                local d = (part.Position - root.Position).Magnitude
                if d < distance then best, distance = item, d end
            end
        end
        return best
    end
    function module:Stop()
        self.enabled, self.generation = false, self.generation + 1
        if self.activePath then self.activePath:Destroy(); self.activePath = nil end
        if self.maid then self.maid:Destroy(); self.maid = nil end
        local hum, root = actor()
        if hum and root then hum:MoveTo(root.Position) end
        if toggle then toggle:Set(false) end
        status.Text = "Coleta interrompida."
    end
    function module:Start()
        if self.enabled then return true end
        if not ctx:RequirePermission() then return false end
        if not ctx.server.worldReady then ui:Notify("Arena indisponível", "Instale o mundo de testes no servidor.", true); return false end
        if ctx.modules.Combat then ctx.modules.Combat:Stop() end
        self.enabled, self.generation = true, self.generation + 1
        local generation = self.generation
        local function active() return ctx.alive and module.enabled and generation == module.generation end
        self.maid = ctx.Maid.new()
        self.maid:Give(task.spawn(function()
            local success, err = pcall(function()
                while active() do
                    local hum, root = actor()
                    local item = root and nearest(root)
                    local part = item and itemPart(item)
                    if not hum then
                        status.Text = "Aguardando personagem vivo..."
                    elseif not part then
                        status.Text = "Aguardando itens da categoria " .. module.category .. "."
                    elseif (root.Position - part.Position).Magnitude <= ctx.server.collectRange - 1 then
                        status.Text = "Coletando " .. item.Name
                        local result = ctx.net:Request("Collect", {target = item})
                        if not active() then break end
                        if result.ok then ctx:SetStats(result.data)
                        else status.Text = result.message end
                    else
                        status.Text = "Caminhando até " .. item.Name
                        local path = Pathfinding:CreatePath({AgentRadius = 2, AgentHeight = 5, AgentCanJump = true, WaypointSpacing = 6})
                        module.activePath = path
                        local computed = pcall(function() path:ComputeAsync(root.Position, part.Position) end)
                        local points = computed and path.Status == Enum.PathStatus.Success and path:GetWaypoints() or nil
                        if not active() then path:Destroy(); break end
                        if not points then
                            status.Text = "Sem caminho disponível para " .. item.Name .. ". Recalculando..."
                        else
                            for _, point in ipairs(points) do
                                if not active() or not item.Parent or item:GetAttribute("Available") ~= true then break end
                                local currentHum, currentRoot = actor()
                                if not currentHum or currentHum ~= hum then break end
                                if (currentRoot.Position - part.Position).Magnitude <= ctx.server.collectRange - 1 then break end
                                if point.Action == Enum.PathWaypointAction.Jump then hum.Jump = true end
                                hum:MoveTo(point.Position)
                                local deadline = os.clock() + 3
                                repeat task.wait(0.1)
                                    currentHum, currentRoot = actor()
                                until not active() or currentHum ~= hum or not currentRoot
                                    or (currentRoot.Position - point.Position).Magnitude < 3 or os.clock() > deadline
                                if os.clock() > deadline then break end
                            end
                        end
                        path:Destroy()
                        module.activePath = nil
                    end
                    task.wait(0.65)
                end
            end)
            if not success and active() then
                module.enabled = false
                toggle:Set(false)
                ui:Notify("Item Farm interrompido", tostring(err):sub(1, 160), true)
            end
        end))
        return true
    end
    ui:Cycle(card, "Categoria", ctx.config.Categories, 1, function(value) module.category = value end)
    toggle = ui:Toggle(card, "Coleta automática", false, function(value)
        if value then return module:Start() end
        module:Stop(); return true
    end)
    local notes = ui:Section(page, "Itens do próprio projeto", "Somente objetos com a tag SnowHubItem dentro de SnowHubTestWorld são aceitos.")
    ui:Label(notes, "O contador registra coletas confirmadas, não movimentos ou tentativas. Os itens da demonstração reaparecem após 12 segundos.")
    function module:UpdateStats(stats) counter.Text = "Coletados nesta sessão: " .. tostring(stats.items or 0) end
    module.Destroy = module.Stop
    return module
end
