-- Built by Olivia — https://discord.gg/ojailbreaks
return function(ctx)
    local Replicated = game:GetService("ReplicatedStorage")
    local Http = game:GetService("HttpService")
    local net = {maid = ctx.Maid.new(), pending = {}, alive = true, count = 0, latency = 0}
    local runtime = Replicated:WaitForChild("SnowHubRuntime", 6)
    if runtime and runtime:GetAttribute("Ready") and runtime:GetAttribute("Protocol") == ctx.config.Protocol then
        net.request = runtime:FindFirstChild("Request")
        net.response = runtime:FindFirstChild("Response")
        net.feedback = runtime:FindFirstChild("Feedback")
    end
    net.available = net.request and net.request:IsA("RemoteEvent") and net.response
        and net.response:IsA("RemoteEvent") and net.feedback and net.feedback:IsA("RemoteEvent") or false
    function net:Finish(id, result)
        local entry = self.pending[id]
        if not entry then return end
        self.pending[id], self.count = nil, self.count - 1
        if entry.timer then pcall(task.cancel, entry.timer) end
        self.latency = math.floor((os.clock() - entry.started) * 1000)
        entry.signal:Fire(result)
        task.defer(function() entry.signal:Destroy() end)
    end
    if net.available then
        net.maid:Connect(net.response.OnClientEvent, function(id, result)
            if type(result) ~= "table" or type(result.ok) ~= "boolean" then return end
            net:Finish(id, result)
        end)
    end
    function net:Request(action, payload)
        if not self.alive or not self.available then
            return {ok = false, message = "Servidor Snow Hub não instalado. Abra o projeto de testes preparado."}
        end
        if self.count >= 4 then return {ok = false, message = "Há ações pendentes. Aguarde."} end
        local id = Http:GenerateGUID(false)
        local entry = {signal = Instance.new("BindableEvent"), started = os.clock()}
        self.pending[id], self.count = entry, self.count + 1
        entry.timer = task.delay(ctx.config.RequestTimeout, function()
            entry.timer = nil
            self:Finish(id, {ok = false, message = "O servidor não respondeu dentro do prazo."})
        end)
        local sent = pcall(function() self.request:FireServer(id, action, payload) end)
        if not sent then
            task.defer(function() self:Finish(id, {ok = false, message = "Conexão com o servidor indisponível."}) end)
        end
        return entry.signal.Event:Wait()
    end
    function net:Destroy()
        if not self.alive then return end
        self.alive = false
        self.maid:Destroy()
        local ids = {}
        for id in pairs(self.pending) do ids[#ids + 1] = id end
        for _, id in ipairs(ids) do self:Finish(id, {ok = false, message = "Snow Hub encerrado."}) end
    end
    return net
end
