-- Built by Olivia — https://discord.gg/ojailbreaks
return function(ctx)
    local ui = ctx.ui
    local module = {rows = nil, stopped = false}
    local card = ui:Section(ctx.pages.Servers, "🌐 Instâncias autorizadas", "Somente servidores públicos deste mesmo place que executam o backend Snow Hub aparecem aqui.")
    local current = ui:Label(card, "Servidor atual: verificando...")
    local status = ui:Label(card, "Atualize para buscar instâncias ativas.")
    local results = ui:Create("Frame", {Size = UDim2.new(1, 0, 0, 0), AutomaticSize = Enum.AutomaticSize.Y,
        BackgroundTransparency = 1, LayoutOrder = 100}, card)
    ui:Create("UIListLayout", {Padding = UDim.new(0, 8)}, results)
    function module:Clear()
        if self.rows then self.rows:Destroy(); self.rows = nil end
        for _, child in ipairs(results:GetChildren()) do
            if not child:IsA("UIListLayout") then child:Destroy() end
        end
    end
    function module:Refresh()
        if not ctx:RequirePermission() then return end
        if not ctx.server.serverHop then
            status.Text = ctx.server.serverReason or "Navegação indisponível nesta instância."
            ui:Notify("Server Hop", status.Text, true)
            return
        end
        self.stopped = false
        status.Text = "Consultando registro autorizado..."
        local result = ctx.net:Request("Servers")
        if not ctx.alive or self.stopped then return end
        self:Clear()
        if not result.ok then status.Text = result.message; return end
        self.rows = ctx.Maid.new()
        status.Text = #result.data == 0 and "Nenhuma outra instância disponível. Abra um segundo servidor público do projeto."
            or (#result.data .. " instância(s) disponível(is).")
        for _, entry in ipairs(result.data) do
            local id = entry.id
            local row = ui:Create("TextButton", {Size = UDim2.new(1, 0, 0, 39), BackgroundColor3 = Color3.fromRGB(229, 237, 246),
                Text = string.sub(id, 1, 12) .. "…  |  " .. entry.players .. "/" .. entry.capacity .. "  |  Entrar",
                Font = Enum.Font.GothamMedium, TextSize = 13, TextColor3 = Color3.fromRGB(37, 49, 66), BorderSizePixel = 0}, results)
            ui:Create("UICorner", {CornerRadius = UDim.new(0, 8)}, row)
            self.rows:Connect(row.Activated, function()
                ui:Confirm("Trocar de instância?", "Destino: " .. id .. "\nAs funções serão interrompidas antes do teleporte.", function()
                    ctx:StopAll(false)
                    local answer = ctx.net:Request("Hop", {id = id})
                    if ctx.alive then ui:Notify("Server Hop", answer.ok and "Teleporte solicitado. Aguarde o Roblox." or answer.message, not answer.ok) end
                end)
            end)
        end
    end
    ui:Button(card, "Atualizar servidores", function() module:Refresh() end)
    function module:Connected()
        current.Text = "Servidor atual: " .. ((ctx.server.jobId or "") ~= "" and ctx.server.jobId or "Studio — sessão local")
        status.Text = ctx.server.serverHop and "Pronto para consultar instâncias." or (ctx.server.serverReason or "Navegação indisponível.")
    end
    function module:Stop()
        self.stopped = true
        self:Clear()
    end
    module.Destroy = module.Stop
    return module
end
