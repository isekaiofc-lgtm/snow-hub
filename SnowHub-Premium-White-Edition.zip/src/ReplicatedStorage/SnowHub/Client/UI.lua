-- Built by Olivia — https://discord.gg/ojailbreaks
return function(ctx)
    local TweenService = game:GetService("TweenService")
    local UIS = game:GetService("UserInputService")
    local RunService = game:GetService("RunService")
    local Lighting = game:GetService("Lighting")
    local player = game:GetService("Players").LocalPlayer
    local ui = {maid = ctx.Maid.new(), pages = {}, tabs = {}, tweens = {}, notices = {},
        reducedMotion = false, alive = true, busyConfirm = false}
    local ink = Color3.fromRGB(37, 49, 66)
    local muted = Color3.fromRGB(105, 120, 141)
    local accent = Color3.fromRGB(108, 157, 196)
    local pale = Color3.fromRGB(229, 237, 246)
    function ui:Create(class, props, parent)
        local o = Instance.new(class)
        for k, v in pairs(props or {}) do o[k] = v end
        o.Parent = parent
        return o
    end
    local function create(...) return ui:Create(...) end
    local function corner(o, radius) create("UICorner", {CornerRadius = UDim.new(0, radius or 12)}, o) end
    local function stroke(o, color)
        create("UIStroke", {Color = color or Color3.fromRGB(212, 222, 233), Thickness = 1, Transparency = 0.12}, o)
    end
    local function text(parent, value, size, props)
        local p = {BackgroundTransparency = 1, Text = value, Font = Enum.Font.Gotham,
            TextSize = size or 14, TextColor3 = ink, TextXAlignment = Enum.TextXAlignment.Left,
            TextWrapped = true, Size = UDim2.new(1, 0, 0, 28)}
        for k, v in pairs(props or {}) do p[k] = v end
        return create("TextLabel", p, parent)
    end
    function ui:Tween(object, props, duration)
        if not self.alive or not object.Parent then return end
        if self.reducedMotion then for k, v in pairs(props) do object[k] = v end; return end
        local tween = TweenService:Create(object, TweenInfo.new(duration or 0.22, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), props)
        self.tweens[tween] = true
        tween.Completed:Once(function() self.tweens[tween] = nil; tween:Destroy() end)
        tween:Play()
    end
    ui.gui = create("ScreenGui", {Name = "SnowHubUI", ResetOnSpawn = false, DisplayOrder = 180,
        ZIndexBehavior = Enum.ZIndexBehavior.Sibling}, player:WaitForChild("PlayerGui"))
    ui.maid:Give(ui.gui)
    ui.blur = create("BlurEffect", {Name = "SnowHubOwnedBlur", Size = 0, Enabled = true}, Lighting)
    ui.maid:Give(ui.blur)
    ui.main = create("CanvasGroup", {Size = UDim2.fromOffset(880, 574), AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.fromScale(0.5, 0.5), BackgroundColor3 = Color3.fromRGB(246, 249, 253),
        BackgroundTransparency = 0.08, GroupTransparency = 1, Visible = false, BorderSizePixel = 0}, ui.gui)
    corner(ui.main, 18); stroke(ui.main)
    create("UIGradient", {Color = ColorSequence.new(Color3.new(1, 1, 1), Color3.fromRGB(226, 235, 246)), Rotation = 115}, ui.main)
    local scale = create("UIScale", {Scale = 1}, ui.main)
    local function resize()
        local camera = workspace.CurrentCamera
        if camera then scale.Scale = math.clamp(math.min((camera.ViewportSize.X - 32) / 880,
            (camera.ViewportSize.Y - 32) / 574), 0.35, 1) end
    end
    local cameraConnection
    local function watchCamera()
        if cameraConnection then cameraConnection:Disconnect() end
        local camera = workspace.CurrentCamera
        if camera then cameraConnection = camera:GetPropertyChangedSignal("ViewportSize"):Connect(resize) end
        resize()
    end
    ui.maid:Connect(workspace:GetPropertyChangedSignal("CurrentCamera"), watchCamera)
    ui.maid:Give(function() if cameraConnection then cameraConnection:Disconnect() end end)
    watchCamera()
    local side = create("Frame", {Size = UDim2.new(0, 188, 1, 0), BackgroundColor3 = Color3.new(1, 1, 1),
        BackgroundTransparency = 0.32, BorderSizePixel = 0}, ui.main)
    text(side, "❄", 34, {Position = UDim2.fromOffset(19, 16), Size = UDim2.fromOffset(40, 40), TextColor3 = accent})
    text(side, "SNOW HUB", 19, {Position = UDim2.fromOffset(18, 65), Font = Enum.Font.GothamBold})
    text(side, "PREMIUM WHITE EDITION", 9, {Position = UDim2.fromOffset(19, 94), TextColor3 = muted})
    local nav = create("Frame", {Position = UDim2.fromOffset(14, 141), Size = UDim2.new(1, -28, 0, 300), BackgroundTransparency = 1}, side)
    create("UIListLayout", {Padding = UDim.new(0, 7), SortOrder = Enum.SortOrder.LayoutOrder}, nav)
    text(side, "Built by Olivia\ndiscord.gg/ojailbreaks", 10, {Position = UDim2.new(0, 18, 1, -64), Size = UDim2.new(1, -30, 0, 40), TextColor3 = muted})
    local titleBar = create("Frame", {Position = UDim2.fromOffset(202, 12), Size = UDim2.new(1, -218, 0, 50), BackgroundTransparency = 1, Active = true}, ui.main)
    ui.heading = text(titleBar, "Dashboard", 23, {Size = UDim2.new(1, -105, 1, 0), Font = Enum.Font.GothamBold})
    local minimize = create("TextButton", {Position = UDim2.new(1, -76, 0, 6), Size = UDim2.fromOffset(32, 32), Text = "−",
        BackgroundColor3 = pale, TextColor3 = ink, BorderSizePixel = 0, TextSize = 22}, titleBar)
    corner(minimize, 8)
    local close = create("TextButton", {Position = UDim2.new(1, -36, 0, 6), Size = UDim2.fromOffset(32, 32), Text = "×",
        BackgroundColor3 = pale, TextColor3 = ink, BorderSizePixel = 0, TextSize = 22}, titleBar)
    corner(close, 8)
    ui.maid:Connect(minimize.Activated, function() ui:SetVisible(false) end)
    ui.maid:Connect(close.Activated, function()
        ui:Confirm("Fechar Snow Hub?", "Todas as funções e conexões do cliente serão encerradas.", function() ctx:Destroy() end)
    end)
    ui.body = create("Frame", {Position = UDim2.fromOffset(205, 70), Size = UDim2.new(1, -223, 1, -108), BackgroundTransparency = 1}, ui.main)
    ui.footer = text(ui.main, "Conectando ao ambiente de testes...", 11, {Position = UDim2.new(0, 205, 1, -30),
        Size = UDim2.new(1, -226, 0, 20), TextColor3 = muted})
    local dragging, initialMouse, initialPosition
    ui.maid:Connect(titleBar.InputBegan, function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1 then
            dragging, initialMouse, initialPosition = true, input.Position, ui.main.Position
        end
    end)
    ui.maid:Connect(UIS.InputChanged, function(input)
        if dragging and input.UserInputType == Enum.UserInputType.MouseMovement then
            local delta = input.Position - initialMouse
            local viewport = workspace.CurrentCamera and workspace.CurrentCamera.ViewportSize
            if viewport then
                local x = initialPosition.X.Scale * viewport.X + initialPosition.X.Offset + delta.X
                local y = initialPosition.Y.Scale * viewport.Y + initialPosition.Y.Offset + delta.Y
                local halfW, halfH = 440 * scale.Scale, 287 * scale.Scale
                ui.main.Position = UDim2.fromOffset(math.clamp(x, halfW, math.max(halfW, viewport.X - halfW)),
                    math.clamp(y, halfH, math.max(halfH, viewport.Y - halfH)))
            end
        end
    end)
    ui.maid:Connect(UIS.InputEnded, function(input) if input.UserInputType == Enum.UserInputType.MouseButton1 then dragging = false end end)
    ui.maid:Connect(UIS.InputBegan, function(input, processed)
        if not processed and input.KeyCode == ctx.config.ToggleKey then ui:SetVisible(not ui.main.Visible) end
    end)
    ui.restore = create("TextButton", {Text = "❄ SNOW HUB", Size = UDim2.fromOffset(140, 38), Position = UDim2.new(0, 18, 0.5, -19),
        BackgroundColor3 = Color3.fromRGB(242, 248, 255), TextColor3 = ink, Font = Enum.Font.GothamBold, TextSize = 13, Visible = false}, ui.gui)
    corner(ui.restore, 12); stroke(ui.restore)
    ui.maid:Connect(ui.restore.Activated, function() ui:SetVisible(true) end)
    function ui:SetVisible(value)
        self.main.Visible, self.restore.Visible = value, not value
        self.blur.Size = value and self.useBlur and 10 or 0
    end
    function ui:SetBlur(value)
        self.useBlur = value
        self:Tween(self.blur, {Size = self.main.Visible and value and 10 or 0})
    end
    function ui:Page(name, icon)
        local index = #nav:GetChildren()
        local tab = create("TextButton", {Size = UDim2.new(1, 0, 0, 41), Text = icon .. "   " .. name,
            LayoutOrder = index, Font = Enum.Font.GothamMedium, TextSize = 14, TextColor3 = muted,
            BackgroundColor3 = Color3.fromRGB(220, 233, 246), BackgroundTransparency = 1, BorderSizePixel = 0,
            TextXAlignment = Enum.TextXAlignment.Left}, nav)
        corner(tab, 9)
        create("UIPadding", {PaddingLeft = UDim.new(0, 12)}, tab)
        local page = create("ScrollingFrame", {Name = name, Size = UDim2.fromScale(1, 1), BackgroundTransparency = 1,
            BorderSizePixel = 0, ScrollBarThickness = 3, ScrollBarImageColor3 = accent,
            AutomaticCanvasSize = Enum.AutomaticSize.Y, CanvasSize = UDim2.new(), Visible = false}, self.body)
        create("UIPadding", {PaddingLeft = UDim.new(0, 3), PaddingRight = UDim.new(0, 8), PaddingBottom = UDim.new(0, 10)}, page)
        create("UIListLayout", {Padding = UDim.new(0, 10), SortOrder = Enum.SortOrder.LayoutOrder}, page)
        self.pages[name], self.tabs[name] = page, tab
        self.maid:Connect(tab.Activated, function() self:Select(name) end)
        return page
    end
    function ui:Select(name)
        self.heading.Text = name
        for key, page in pairs(self.pages) do
            page.Visible = key == name
            self:Tween(self.tabs[key], {BackgroundTransparency = key == name and 0.12 or 1,
                TextColor3 = key == name and ink or muted})
        end
    end
    function ui:Section(page, title, subtitle)
        local card = create("Frame", {Size = UDim2.new(1, -2, 0, 0), AutomaticSize = Enum.AutomaticSize.Y,
            BackgroundColor3 = Color3.new(1, 1, 1), BackgroundTransparency = 0.24, BorderSizePixel = 0,
            LayoutOrder = #page:GetChildren()}, page)
        corner(card, 12); stroke(card)
        create("UIPadding", {PaddingTop = UDim.new(0, 15), PaddingBottom = UDim.new(0, 15),
            PaddingLeft = UDim.new(0, 16), PaddingRight = UDim.new(0, 16)}, card)
        create("UIListLayout", {Padding = UDim.new(0, 9), SortOrder = Enum.SortOrder.LayoutOrder}, card)
        text(card, title, 16, {Font = Enum.Font.GothamBold, LayoutOrder = 0})
        if subtitle then text(card, subtitle, 12, {AutomaticSize = Enum.AutomaticSize.Y,
            Size = UDim2.new(1, 0, 0, 20), TextColor3 = muted, LayoutOrder = 1}) end
        return card
    end
    function ui:Label(parent, value)
        return text(parent, value, 13, {LayoutOrder = #parent:GetChildren(), AutomaticSize = Enum.AutomaticSize.Y,
            Size = UDim2.new(1, 0, 0, 24), TextColor3 = muted})
    end
    function ui:Button(parent, label, callback)
        local b = create("TextButton", {Size = UDim2.new(1, 0, 0, 37), BackgroundColor3 = pale, BorderSizePixel = 0,
            Text = label, Font = Enum.Font.GothamMedium, TextSize = 13, TextColor3 = ink, LayoutOrder = #parent:GetChildren()}, parent)
        corner(b, 8)
        local working = false
        self.maid:Connect(b.MouseEnter, function() self:Tween(b, {BackgroundColor3 = Color3.fromRGB(210, 226, 242)}) end)
        self.maid:Connect(b.MouseLeave, function() self:Tween(b, {BackgroundColor3 = pale}) end)
        self.maid:Connect(b.Activated, function()
            if working or not self.alive then return end
            working = true
            local success, err = pcall(callback, b)
            working = false
            if not success and self.alive then self:Notify("Ação interrompida", tostring(err):sub(1, 160), true) end
        end)
        return b
    end
    function ui:Toggle(parent, label, initial, callback)
        local value = initial
        local b
        local function paint()
            if b and b.Parent then b.Text = label .. (value and "  •  ATIVO" or "  •  DESLIGADO") end
        end
        b = self:Button(parent, label, function()
            local requested = not value
            local accepted = callback(requested)
            if accepted ~= false then value = requested end
            paint()
        end)
        paint()
        return {Set = function(_, v) value = v; paint() end, Get = function() return value end}
    end
    function ui:Cycle(parent, label, values, index, callback)
        local b = self:Button(parent, label .. ": " .. tostring(values[index]), function(button)
            index = index % #values + 1
            button.Text = label .. ": " .. tostring(values[index])
            callback(values[index], index)
        end)
        return b
    end
    function ui:Slider(parent, label, low, high, initial, callback)
        local row = create("Frame", {Size = UDim2.new(1, 0, 0, 53), BackgroundTransparency = 1,
            LayoutOrder = #parent:GetChildren()}, parent)
        local caption = text(row, label, 13, {Size = UDim2.new(1, 0, 0, 23)})
        local bar = create("TextButton", {Position = UDim2.fromOffset(0, 35), Size = UDim2.new(1, 0, 0, 7),
            Text = "", BackgroundColor3 = pale, BorderSizePixel = 0, AutoButtonColor = false}, row)
        corner(bar, 4)
        local fill = create("Frame", {Size = UDim2.fromScale(0, 1), BackgroundColor3 = accent, BorderSizePixel = 0}, bar)
        corner(fill, 4)
        local dot = create("Frame", {Size = UDim2.fromOffset(14, 14), AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(1, 0.5), BackgroundColor3 = Color3.new(1, 1, 1)}, fill)
        corner(dot, 7); stroke(dot, accent)
        local held = false
        local function set(value, invoke)
            value = math.floor(math.clamp(value, low, high) * 100 + 0.5) / 100
            fill.Size = UDim2.fromScale((value - low) / (high - low), 1)
            caption.Text = label .. "  " .. tostring(value)
            if invoke then callback(value) end
        end
        local function pointer()
            local x = UIS:GetMouseLocation().X
            set(low + math.clamp((x - bar.AbsolutePosition.X) / math.max(1, bar.AbsoluteSize.X), 0, 1) * (high - low), true)
        end
        self.maid:Connect(bar.InputBegan, function(input)
            if input.UserInputType == Enum.UserInputType.MouseButton1 then held = true; pointer() end
        end)
        self.maid:Connect(UIS.InputChanged, function(input)
            if held and input.UserInputType == Enum.UserInputType.MouseMovement then pointer() end
        end)
        self.maid:Connect(UIS.InputEnded, function(input) if input.UserInputType == Enum.UserInputType.MouseButton1 then held = false end end)
        set(initial, false)
    end
    ui.toastRoot = create("Frame", {Position = UDim2.new(1, -354, 1, -22), Size = UDim2.fromOffset(336, 340),
        AnchorPoint = Vector2.new(0, 1), BackgroundTransparency = 1}, ui.gui)
    create("UIListLayout", {Padding = UDim.new(0, 8), VerticalAlignment = Enum.VerticalAlignment.Bottom,
        SortOrder = Enum.SortOrder.LayoutOrder}, ui.toastRoot)
    function ui:Notify(title, message, bad)
        if not self.alive then return end
        while #self.notices >= 4 do
            local old = table.remove(self.notices, 1)
            old:Destroy()
        end
        local card = create("CanvasGroup", {Size = UDim2.new(1, 0, 0, 80), BackgroundColor3 = Color3.fromRGB(245, 249, 255),
            BorderSizePixel = 0, GroupTransparency = 1}, self.toastRoot)
        corner(card, 11); stroke(card, bad and Color3.fromRGB(209, 158, 161) or nil)
        text(card, (bad and "!  " or "❄  ") .. title, 13, {Position = UDim2.fromOffset(14, 8),
            Size = UDim2.new(1, -28, 0, 22), Font = Enum.Font.GothamBold})
        text(card, message, 12, {Position = UDim2.fromOffset(14, 32), Size = UDim2.new(1, -28, 0, 41), TextColor3 = muted})
        self.notices[#self.notices + 1] = card
        self:Tween(card, {GroupTransparency = 0})
        task.delay(5, function()
            if not self.alive or not card.Parent then return end
            self:Tween(card, {GroupTransparency = 1})
            task.delay(0.3, function()
                local index = table.find(self.notices, card)
                if index then table.remove(self.notices, index) end
                card:Destroy()
            end)
        end)
    end
    function ui:Confirm(title, message, callback)
        if self.busyConfirm then return end
        self.busyConfirm = true
        local modalMaid = ctx.Maid.new()
        local overlay = create("Frame", {Size = UDim2.fromScale(1, 1), BackgroundColor3 = Color3.fromRGB(48, 61, 81),
            BackgroundTransparency = 0.4, Active = true, ZIndex = 30}, self.gui)
        local box = create("Frame", {Size = UDim2.fromOffset(380, 215), AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5), BackgroundColor3 = Color3.fromRGB(247, 250, 255), ZIndex = 31}, overlay)
        corner(box, 14); stroke(box)
        text(box, title, 18, {Position = UDim2.fromOffset(20, 17), Size = UDim2.new(1, -40, 0, 35), ZIndex = 32, Font = Enum.Font.GothamBold})
        text(box, message, 13, {Position = UDim2.fromOffset(20, 58), Size = UDim2.new(1, -40, 0, 74), ZIndex = 32, TextColor3 = muted})
        local function finish()
            self.busyConfirm = false
            modalMaid:Destroy()
            overlay:Destroy()
        end
        for i, label in ipairs({"Cancelar", "Confirmar"}) do
            local b = create("TextButton", {Size = UDim2.fromOffset(162, 36), Position = UDim2.fromOffset(20 + (i - 1) * 178, 155),
                Text = label, BackgroundColor3 = i == 2 and Color3.fromRGB(193, 215, 238) or pale,
                TextColor3 = ink, TextSize = 13, Font = Enum.Font.GothamMedium, BorderSizePixel = 0, ZIndex = 32}, box)
            corner(b, 8)
            local confirm = i == 2
            modalMaid:Connect(b.Activated, function()
                finish()
                if confirm and self.alive then
                    task.spawn(function()
                        local success, err = pcall(callback)
                        if not success then self:Notify("Falha", tostring(err):sub(1, 160), true) end
                    end)
                end
            end)
        end
        self.maid:Give(modalMaid)
    end
    function ui:StartLoading()
        self.loadingMaid = ctx.Maid.new()
        self.splash = create("CanvasGroup", {Size = UDim2.fromOffset(440, 290), Position = UDim2.fromScale(0.5, 0.5),
            AnchorPoint = Vector2.new(0.5, 0.5), BackgroundColor3 = Color3.fromRGB(244, 249, 255), ClipsDescendants = true}, self.gui)
        corner(self.splash, 18); stroke(self.splash)
        text(self.splash, "SNOW HUB", 30, {Position = UDim2.fromOffset(40, 65), Size = UDim2.new(1, -80, 0, 43),
            Font = Enum.Font.GothamBold, TextXAlignment = Enum.TextXAlignment.Center})
        text(self.splash, "Loading your experience...", 14, {Position = UDim2.fromOffset(40, 120), Size = UDim2.new(1, -80, 0, 30),
            TextColor3 = muted, TextXAlignment = Enum.TextXAlignment.Center})
        local track = create("Frame", {Position = UDim2.fromOffset(45, 190), Size = UDim2.new(1, -90, 0, 7),
            BackgroundColor3 = pale, BorderSizePixel = 0}, self.splash)
        corner(track, 4)
        self.progress = create("Frame", {Size = UDim2.fromScale(0, 1), BackgroundColor3 = accent, BorderSizePixel = 0}, track)
        corner(self.progress, 4)
        self.loadingLabel = text(self.splash, "Preparando interface", 11, {Position = UDim2.fromOffset(45, 215),
            Size = UDim2.new(1, -90, 0, 25), TextColor3 = muted, TextXAlignment = Enum.TextXAlignment.Center})
        local flakes = {}
        local random = Random.new()
        for i = 1, 15 do
            local f = text(self.splash, "❄", random:NextInteger(12, 22), {Size = UDim2.fromOffset(28, 28),
                TextColor3 = Color3.fromRGB(185, 207, 229), TextTransparency = 0.35})
            flakes[i] = {label = f, x = random:NextNumber(), y = random:NextNumber(), speed = random:NextNumber(0.06, 0.14)}
        end
        self.loadingMaid:Connect(RunService.RenderStepped, function(dt)
            if self.reducedMotion then return end
            for _, f in ipairs(flakes) do
                f.y = (f.y + dt * f.speed) % 1
                f.label.Position = UDim2.fromScale(f.x, f.y)
                f.label.Rotation = f.label.Rotation + dt * 12
            end
        end)
    end
    function ui:Progress(value, label)
        if self.progress then self:Tween(self.progress, {Size = UDim2.fromScale(math.clamp(value, 0, 1), 1)}, 0.35) end
        if self.loadingLabel then self.loadingLabel.Text = label end
    end
    function ui:FinishLoading()
        self:Progress(1, "Pronto")
        task.wait(0.4)
        if not self.alive then return end
        self.loadingMaid:Destroy()
        self:Tween(self.splash, {GroupTransparency = 1}, 0.3)
        self.main.Visible = true
        self:Tween(self.main, {GroupTransparency = 0}, 0.4)
        task.delay(0.4, function() if self.splash then self.splash:Destroy() end end)
    end
    function ui:Destroy()
        if not self.alive then return end
        self.alive = false
        if self.loadingMaid then self.loadingMaid:Destroy() end
        for tween in pairs(self.tweens) do tween:Cancel(); tween:Destroy() end
        self.tweens = {}
        self.maid:Destroy()
    end
    return ui
end
