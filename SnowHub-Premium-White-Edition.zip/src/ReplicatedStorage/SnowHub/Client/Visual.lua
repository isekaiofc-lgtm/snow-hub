-- Built by Olivia — https://discord.gg/ojailbreaks
return function(ctx)
    local Collection = game:GetService("CollectionService")
    local Players = game:GetService("Players")
    local RunService = game:GetService("RunService")
    local module = {npc = false, items = false, boxes = false, alpha = 0.6,
        color = Color3.fromRGB(116, 178, 231), markers = {}, maid = nil}
    local ui = ctx.ui
    local card = ui:Section(ctx.pages.Visual, "👁 ESP de Testes", "Nomes e distâncias dos objetos de teste replicados para este cliente.")
    local boxCard = ui:Section(ctx.pages.Visual, "🎯 Hitbox Visualizer", "Caixas visuais usam as dimensões reais das peças. Nenhuma hitbox física é alterada.")
    local toggles = {}
    local function remove(object)
        local entry = module.markers[object]
        if entry then entry.maid:Destroy(); module.markers[object] = nil end
    end
    local function partOf(object)
        return object:IsA("BasePart") and object or object:IsA("Model")
            and (object.PrimaryPart or object:FindFirstChild("HumanoidRootPart") or object:FindFirstChildWhichIsA("BasePart", true))
    end
    local function update()
        local ch = Players.LocalPlayer.Character
        local root = ch and ch:FindFirstChild("HumanoidRootPart")
        local world = workspace:FindFirstChild(ctx.config.WorldName)
        local wanted = {}
        local function add(tag, isNPC)
            for _, object in ipairs(Collection:GetTagged(tag)) do
                local part = partOf(object)
                local hum = isNPC and object:FindFirstChildOfClass("Humanoid")
                if world and object:IsDescendantOf(world) and part
                    and ((isNPC and hum and hum.Health > 0) or (not isNPC and object:GetAttribute("Available") == true)) then
                    table.insert(wanted, {object = object, part = part, npc = isNPC,
                        distance = root and (root.Position - part.Position).Magnitude or 0})
                end
            end
        end
        if module.npc or module.boxes then add(ctx.config.NPCTag, true) end
        if module.items then add(ctx.config.ItemTag, false) end
        table.sort(wanted, function(a, b) return a.distance < b.distance end)
        local keep = {}
        for i = 1, math.min(#wanted, ctx.config.MarkerLimit) do keep[wanted[i].object] = true end
        local stale = {}
        for object in pairs(module.markers) do if not keep[object] then table.insert(stale, object) end end
        for _, object in ipairs(stale) do remove(object) end
        for i = 1, math.min(#wanted, ctx.config.MarkerLimit) do
            local record = wanted[i]
            local object, part = record.object, record.part
            local entry = module.markers[object]
            if entry and entry.part ~= part then remove(object); entry = nil end
            if not entry then
                local maid = ctx.Maid.new()
                entry = {maid = maid, part = part, boxes = {}}
                entry.highlight = maid:Give(ui:Create("Highlight", {Adornee = object,
                    DepthMode = Enum.HighlightDepthMode.AlwaysOnTop, FillTransparency = 0.85}, ctx.visualRoot))
                entry.billboard = maid:Give(ui:Create("BillboardGui", {Adornee = part, AlwaysOnTop = true,
                    Size = UDim2.fromOffset(240, 42), StudsOffsetWorldSpace = Vector3.new(0, 4, 0)}, ui.gui))
                entry.label = ui:Create("TextLabel", {Size = UDim2.fromScale(1, 1), BackgroundTransparency = 1,
                    Font = Enum.Font.GothamBold, TextSize = 12, TextColor3 = Color3.new(1, 1, 1),
                    TextStrokeTransparency = 0.2, TextWrapped = true}, entry.billboard)
                module.markers[object] = entry
            end
            local espOn = record.npc and module.npc or not record.npc and module.items
            entry.highlight.Enabled, entry.billboard.Enabled = espOn, espOn
            entry.highlight.FillColor, entry.highlight.OutlineColor = module.color, module.color
            entry.label.Text = object.Name .. "  |  " .. math.floor(record.distance) .. " studs"
            if record.npc then
                local seen = {}
                for _, bodyPart in ipairs(object:GetDescendants()) do
                    if bodyPart:IsA("BasePart") and bodyPart.Name ~= "HumanoidRootPart" then
                        seen[bodyPart] = true
                        local adornment = entry.boxes[bodyPart]
                        if module.boxes and not adornment then
                            adornment = ui:Create("BoxHandleAdornment", {Adornee = bodyPart, AlwaysOnTop = true,
                                ZIndex = 1, Size = bodyPart.Size}, ctx.visualRoot)
                            entry.boxes[bodyPart] = adornment
                            entry.maid:Give(adornment)
                        end
                        if adornment then
                            adornment.Visible, adornment.Transparency = module.boxes, module.alpha
                            adornment.Color3, adornment.Size = module.color, bodyPart.Size
                        end
                    end
                end
                for bodyPart, adornment in pairs(entry.boxes) do
                    if not seen[bodyPart] then adornment:Destroy(); entry.boxes[bodyPart] = nil end
                end
            end
        end
    end
    function module:Reconcile()
        if self.npc or self.items or self.boxes then
            if not self.maid then
                self.maid = ctx.Maid.new()
                local elapsed = 0
                self.maid:Connect(RunService.Heartbeat, function(dt)
                    elapsed = elapsed + dt
                    if elapsed < ctx.config.VisualInterval then return end
                    elapsed = 0
                    local success, err = pcall(update)
                    if not success then
                        self:Stop()
                        ui:Notify("Visual interrompido", tostring(err):sub(1, 150), true)
                    end
                end)
            end
        else
            if self.maid then self.maid:Destroy(); self.maid = nil end
            local old = {}
            for object in pairs(self.markers) do old[#old + 1] = object end
            for _, object in ipairs(old) do remove(object) end
        end
    end
    for _, info in ipairs({{"NPCs", "npc", card}, {"Itens", "items", card}, {"Hitboxes", "boxes", boxCard}}) do
        local key = info[2]
        toggles[key] = ui:Toggle(info[3], info[1], false, function(value)
            if value and not ctx:RequirePermission() then return false end
            module[key] = value
            module:Reconcile()
            return true
        end)
    end
    local palette = {Color3.fromRGB(116, 178, 231), Color3.fromRGB(233, 241, 255), Color3.fromRGB(191, 166, 232), Color3.fromRGB(109, 200, 177)}
    ui:Cycle(boxCard, "Cor dos indicadores", {"Gelo", "Branco-neve", "Lavanda", "Menta"}, 1, function(_, index) module.color = palette[index] end)
    ui:Slider(boxCard, "Transparência", 0, 0.95, module.alpha, function(value) module.alpha = value end)
    function module:Stop()
        self.npc, self.items, self.boxes = false, false, false
        for _, toggle in pairs(toggles) do toggle:Set(false) end
        self:Reconcile()
    end
    module.Destroy = module.Stop
    return module
end
