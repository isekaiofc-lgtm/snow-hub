-- Built by Olivia — https://discord.gg/ojailbreaks
return {
    Name = "SNOW HUB", Edition = "PREMIUM WHITE EDITION", Version = "1.0.0",
    Protocol = 1, ItemTag = "SnowHubItem", NPCTag = "SnowHubNPC",
    WorldName = "SnowHubTestWorld", Categories = {"Todos", "Cristais", "Relíquias", "Moedas"},
    MarkerLimit = 48, VisualInterval = 0.15, RequestTimeout = 8,
    ToggleKey = Enum.KeyCode.RightShift,
}
