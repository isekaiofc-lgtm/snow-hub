-- Built by Olivia — https://discord.gg/ojailbreaks
local Maid = {}
Maid.__index = Maid
function Maid.new()
    return setmetatable({tasks = {}, dead = false}, Maid)
end
local function dispose(value)
    local kind = typeof(value)
    if kind == "RBXScriptConnection" then value:Disconnect()
    elseif kind == "Instance" then value:Destroy()
    elseif kind == "function" then value()
    elseif kind == "thread" then
        if coroutine.status(value) ~= "dead" and value ~= coroutine.running() then task.cancel(value) end
    elseif kind == "table" and value.Destroy then value:Destroy() end
end
function Maid:Give(value)
    if self.dead then pcall(dispose, value) else table.insert(self.tasks, value) end
    return value
end
function Maid:Connect(signal, callback)
    return self:Give(signal:Connect(callback))
end
function Maid:Destroy()
    if self.dead then return end
    self.dead = true
    local tasks = self.tasks
    self.tasks = {}
    for i = #tasks, 1, -1 do
        local ok, err = pcall(dispose, tasks[i])
        if not ok then warn("[Snow Hub] limpeza: " .. tostring(err)) end
    end
end
return Maid
