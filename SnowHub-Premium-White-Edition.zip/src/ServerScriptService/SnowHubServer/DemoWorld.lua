-- Built by Olivia — https://discord.gg/ojailbreaks
return function(config, shared)
    local Collection = game:GetService("CollectionService")
    local world = workspace:FindFirstChild(shared.WorldName)
    if world then return world end
    world = Instance.new("Folder")
    world.Name = shared.WorldName
    world.Parent = workspace
    local function part(name, size, position, color, parent)
        local p = Instance.new("Part")
        p.Name, p.Size, p.Position, p.Color = name, size, position, color
        p.Anchored, p.TopSurface, p.BottomSurface = true, Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
        p.Parent = parent or world
        return p
    end
    local base = config.WorldOrigin
    part("SnowArena", Vector3.new(130, 2, 130), base, Color3.fromRGB(224, 232, 241))
    for i = 1, 4 do
        local a = (i - 1) * math.pi / 2
        local p = part("IcePillar", Vector3.new(3, 17, 3), base + Vector3.new(math.cos(a) * 55, 9, math.sin(a) * 55), Color3.fromRGB(188, 220, 242))
        p.Material = Enum.Material.Glass
        p.Transparency = 0.3
    end
    local spawn = Instance.new("SpawnLocation")
    spawn.Name, spawn.Size, spawn.Position = "SnowSpawn", Vector3.new(8, 1, 8), base + Vector3.new(0, 2, 24)
    spawn.Anchored, spawn.Neutral, spawn.Duration = true, true, 0
    spawn.Color, spawn.Material = Color3.fromRGB(180, 209, 237), Enum.Material.Neon
    spawn.Parent = world
    world:SetAttribute("SpawnCFrame", spawn.CFrame + Vector3.new(0, 4, 0))
    local colors = {Color3.fromRGB(139, 205, 255), Color3.fromRGB(205, 185, 246), Color3.fromRGB(242, 218, 147)}
    for i = 1, 18 do
        local categoryIndex = ((i - 1) % 3) + 1
        local category = shared.Categories[categoryIndex + 1]
        local a = i * math.pi * 2 / 18
        local item = part(category .. " " .. i, Vector3.new(1.8, 1.8, 1.8), base + Vector3.new(math.cos(a) * 29, 3, math.sin(a) * 29), colors[categoryIndex])
        item.Shape, item.Material, item.CanCollide = Enum.PartType.Ball, Enum.Material.Neon, false
        item:SetAttribute("Category", category)
        item:SetAttribute("Available", true)
        item:SetAttribute("ItemId", "demo-item-" .. i)
        Collection:AddTag(item, shared.ItemTag)
    end
    local function spawnDummy(index)
        if not world.Parent then return end
        local model = Instance.new("Model")
        model.Name = "Snow Dummy " .. index
        local position = base + Vector3.new((index - 2) * 11, 4, -8)
        local root = part("HumanoidRootPart", Vector3.new(2, 2, 1), position, Color3.new(1, 1, 1), model)
        root.Transparency, root.CanCollide = 1, false
        local torso = part("Torso", Vector3.new(2, 2, 1), position, Color3.fromRGB(171, 190, 218), model)
        local head = part("Head", Vector3.new(2, 1, 1), position + Vector3.new(0, 1.5, 0), Color3.fromRGB(238, 242, 250), model)
        for side = -1, 1, 2 do
            part(side == -1 and "Left Arm" or "Right Arm", Vector3.new(1, 2, 1), position + Vector3.new(side * 1.5, 0, 0), torso.Color, model)
            part(side == -1 and "Left Leg" or "Right Leg", Vector3.new(1, 2, 1), position + Vector3.new(side * 0.5, -2, 0), head.Color, model)
        end
        local humanoid = Instance.new("Humanoid")
        humanoid.RequiresNeck, humanoid.BreakJointsOnDeath = false, false
        humanoid.MaxHealth, humanoid.Health = 200, 200
        humanoid.DisplayName = "Training " .. index
        humanoid.Parent = model
        model.PrimaryPart = root
        model:SetAttribute("TestNPC", true)
        model.Parent = world
        Collection:AddTag(model, shared.NPCTag)
        humanoid.Died:Once(function()
            Collection:RemoveTag(model, shared.NPCTag)
            task.delay(config.NPCRespawnSeconds, function()
                model:Destroy()
                spawnDummy(index)
            end)
        end)
    end
    for i = 1, 3 do spawnDummy(i) end
    return world
end
