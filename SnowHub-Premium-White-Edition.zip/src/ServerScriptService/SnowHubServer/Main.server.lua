-- Built by Olivia — https://discord.gg/ojailbreaks
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Collection = game:GetService("CollectionService")
local RunService = game:GetService("RunService")
local MemoryStore = game:GetService("MemoryStoreService")
local TeleportService = game:GetService("TeleportService")
local config = require(script.Parent.ServerConfig)
local Rules = require(script.Parent.Rules)
local package = ReplicatedStorage:WaitForChild("SnowHub", 15)
assert(package, "SnowHub ausente em ReplicatedStorage.")
local shared = require(package.Config)
if ReplicatedStorage:FindFirstChild("SnowHubRuntime") then
    warn("[Snow Hub] servidor já inicializado; cópia ignorada.")
    return
end
local runtime = Instance.new("Folder")
runtime.Name = "SnowHubRuntime"
runtime:SetAttribute("Protocol", shared.Protocol)
local function remote(name)
    local r = Instance.new("RemoteEvent")
    r.Name, r.Parent = name, runtime
    return r
end
local request, response, feedback = remote("Request"), remote("Response"), remote("Feedback")
local world = config.CreateDemoWorld and require(script.Parent.DemoWorld)(config, shared)
    or workspace:FindFirstChild(shared.WorldName)
local sessions, connections, closed = {}, {}, false
local registry = MemoryStore:GetSortedMap(config.ServerRegistryName)
local registryEnabled = config.Enabled and config.EnableServerHop and not RunService:IsStudio()
    and game.JobId ~= "" and game.PrivateServerId == ""
local registryError = nil
local lastList, listCache = -math.huge, nil

local function allowed(p)
    return Rules.allowed(config, RunService:IsStudio(), p.UserId, game.CreatorId,
        game.CreatorType == Enum.CreatorType.User)
end
local function rootOf(object)
    if object:IsA("BasePart") then return object end
    return object:IsA("Model") and (object.PrimaryPart or object:FindFirstChild("HumanoidRootPart")
        or object:FindFirstChildWhichIsA("BasePart", true)) or nil
end
local function session(p)
    local s = sessions[p]
    if not s then
        s = {items = 0, hits = 0, damage = 0, kills = 0, misses = 0,
            started = os.clock(), bucket = {tokens = 12, updated = os.clock()}, actions = {}}
        sessions[p] = s
    end
    return s
end
local function snapshot(p)
    local s = session(p)
    return {items = s.items, hits = s.hits, damage = s.damage, kills = s.kills, misses = s.misses,
        elapsed = math.max(0.01, os.clock() - s.started)}
end
local function emit(p, event, data)
    if p.Parent == Players then feedback:FireClient(p, event, data) end
end
local function ok(data) return {ok = true, data = data} end
local function fail(message) return {ok = false, message = message} end
local function livingRoot(p)
    local character = p.Character
    local hum = character and character:FindFirstChildOfClass("Humanoid")
    local root = character and character:FindFirstChild("HumanoidRootPart")
    if hum and hum.Health > 0 and root then return root end
end
local function testObject(object, tag)
    return typeof(object) == "Instance" and world and world.Parent
        and object:IsDescendantOf(world) and Collection:HasTag(object, tag)
end
local function handshake(p)
    return ok({protocol = shared.Protocol, version = shared.Version,
        collectRange = config.CollectRange, farmRange = config.FarmSearchRange,
        attackRange = config.AttackRange, attackCooldown = config.AttackCooldown,
        categories = shared.Categories, stats = snapshot(p),
        jobId = game.JobId, placeId = game.PlaceId, isStudio = RunService:IsStudio(),
        worldReady = world ~= nil,
        serverHop = registryEnabled, serverReason = RunService:IsStudio()
            and "Server Hop requer a experiência publicada e o aplicativo Roblox."
            or (game.PrivateServerId ~= "" and "Registro de instâncias públicas indisponível neste servidor privado." or nil)})
end
local function collect(p, payload)
    local item = type(payload) == "table" and payload.target
    if not testObject(item, shared.ItemTag) then return fail("Item fora do ambiente de testes.") end
    if item:GetAttribute("Available") ~= true then return fail("Este item já foi coletado.") end
    local root, itemRoot = livingRoot(p), rootOf(item)
    if not root or not itemRoot then return fail("Personagem ou item indisponível.") end
    if not Rules.inRange((root.Position - itemRoot.Position).Magnitude, config.CollectRange) then
        return fail("Aproxime-se do item para coletar.")
    end
    -- Reserva síncrona: dois jogadores não recebem o mesmo item.
    item:SetAttribute("Available", false)
    local appearance = {}
    local parts = item:IsA("BasePart") and {item} or item:GetDescendants()
    for _, part in ipairs(parts) do
        if part:IsA("BasePart") then
            table.insert(appearance, {part, part.Transparency, part.CanCollide})
            part.Transparency, part.CanCollide = 1, false
        end
    end
    local s = session(p)
    s.items = s.items + 1
    emit(p, "Collected", {name = item.Name, category = item:GetAttribute("Category"), stats = snapshot(p)})
    task.delay(config.ItemRespawnSeconds, function()
        if closed or not item.Parent then return end
        for _, saved in ipairs(appearance) do
            if saved[1].Parent then saved[1].Transparency, saved[1].CanCollide = saved[2], saved[3] end
        end
        item:SetAttribute("Available", true)
    end)
    return ok(snapshot(p))
end
local function attack(p, payload)
    local target = type(payload) == "table" and payload.target
    if not testObject(target, shared.NPCTag) or not target:IsA("Model")
        or Players:GetPlayerFromCharacter(target) then return fail("Selecione um NPC de teste válido.") end
    local root, targetRoot = livingRoot(p), rootOf(target)
    local hum = target:FindFirstChildOfClass("Humanoid")
    if not root or not targetRoot or not hum or hum.Health <= 0 then return fail("NPC indisponível.") end
    local s = session(p)
    if not Rules.inRange((root.Position - targetRoot.Position).Magnitude, config.AttackRange) then
        s.misses = s.misses + 1
        return fail("Fora do alcance de " .. config.AttackRange .. " studs.")
    end
    local rayParams = RaycastParams.new()
    rayParams.FilterType = Enum.RaycastFilterType.Exclude
    rayParams.FilterDescendantsInstances = {p.Character}
    local obstruction = workspace:Raycast(root.Position, targetRoot.Position - root.Position, rayParams)
    if obstruction and not obstruction.Instance:IsDescendantOf(target) then
        s.misses = s.misses + 1
        return fail("Há um obstáculo entre você e o NPC.")
    end
    local before = hum.Health
    hum:TakeDamage(config.AttackDamage)
    local dealt = math.max(0, before - hum.Health)
    s.hits, s.damage = s.hits + 1, s.damage + dealt
    if hum.Health <= 0 then s.kills = s.kills + 1 end
    emit(p, "Damage", {target = target, position = targetRoot.Position,
        damage = dealt, stats = snapshot(p)})
    return ok(snapshot(p))
end
local function listServers()
    if not registryEnabled then
        return fail(RunService:IsStudio() and "Teleporte indisponível no Studio. Publique e abra pelo Roblox."
            or "Navegação indisponível nesta instância.")
    end
    if listCache and os.clock() - lastList < 10 then return ok(listCache) end
    local success, entries = pcall(function() return registry:GetRangeAsync(Enum.SortDirection.Descending, 100) end)
    if not success then return fail("Registro de servidores indisponível; tente novamente em alguns segundos.") end
    local result = {}
    for _, entry in ipairs(entries) do
        local value = entry.value
        if type(value) == "table" and value.placeId == game.PlaceId and entry.key ~= game.JobId
            and type(value.updated) == "number" and os.time() - value.updated < config.ServerTTL
            and type(value.players) == "number" and value.players < value.capacity then
            table.insert(result, {id = entry.key, players = value.players, capacity = value.capacity})
        end
    end
    lastList, listCache = os.clock(), result
    return ok(result)
end
local function hop(p, payload)
    if not registryEnabled then return fail("Server Hop indisponível nesta sessão.") end
    local id = type(payload) == "table" and payload.id
    if type(id) ~= "string" or #id > 64 or id == game.JobId then return fail("Servidor inválido.") end
    local success, entry = pcall(function() return registry:GetAsync(id) end)
    if not success or type(entry) ~= "table" or entry.placeId ~= game.PlaceId
        or os.time() - (entry.updated or 0) >= config.ServerTTL then
        return fail("A instância expirou. Atualize a lista.")
    end
    if entry.players >= entry.capacity then return fail("O servidor ficou cheio.") end
    local options = Instance.new("TeleportOptions")
    options.ServerInstanceId = id
    local sent, err = pcall(function() TeleportService:TeleportAsync(game.PlaceId, {p}, options) end)
    options:Destroy()
    if not sent then warn("[Snow Hub] teleporte: " .. tostring(err)); return fail("Falha ao iniciar teleporte.") end
    return ok({message = "Teleporte solicitado."})
end
local handlers = {
    Handshake = handshake, Stats = function(p) return ok(snapshot(p)) end,
    Collect = collect, Attack = attack,
    Servers = function() return listServers() end, Hop = hop,
    ResetStats = function(p)
        local s = session(p)
        s.items, s.hits, s.damage, s.kills, s.misses, s.started = 0, 0, 0, 0, 0, os.clock()
        return ok(snapshot(p))
    end,
    Arena = function(p)
        local root = livingRoot(p)
        local spawn = world and world:GetAttribute("SpawnCFrame")
        if not root or typeof(spawn) ~= "CFrame" then return fail("Arena indisponível.") end
        p.Character:PivotTo(spawn)
        return ok({message = "Você está na arena de testes."})
    end,
}
local limits = {Handshake = 1, Stats = 0.8, Collect = 0.35, Attack = config.AttackCooldown,
    Servers = 5, Hop = 10, ResetStats = 1, Arena = 2}
connections[#connections + 1] = request.OnServerEvent:Connect(function(p, id, action, payload)
    if type(id) ~= "string" or #id > 64 or type(action) ~= "string" or not handlers[action] then return end
    local s, now = session(p), os.clock()
    if not Rules.takeToken(s.bucket, now) then return end
    if not allowed(p) then response:FireClient(p, id, fail("Sem permissão para o Snow Hub neste projeto.")); return end
    if now - (s.actions[action] or -math.huge) < limits[action] then
        response:FireClient(p, id, fail("Aguarde o intervalo desta ação.")); return
    end
    s.actions[action] = now
    local success, result = pcall(handlers[action], p, payload)
    if not success then warn("[Snow Hub] " .. action .. ": " .. tostring(result)); result = fail("Falha interna; consulte o Output do servidor.") end
    if p.Parent == Players then response:FireClient(p, id, result) end
end)
connections[#connections + 1] = TeleportService.TeleportInitFailed:Connect(function(p, _, message)
    if allowed(p) then emit(p, "Error", {message = "Teleporte não concluído: " .. tostring(message)}) end
end)
connections[#connections + 1] = Players.PlayerRemoving:Connect(function(p) sessions[p] = nil end)
connections[#connections + 1] = Players.PlayerAdded:Connect(function(p)
    if RunService:IsStudio() and config.CreateDemoWorld then
        p.RespawnLocation = world and world:FindFirstChild("SnowSpawn")
    end
end)
runtime:SetAttribute("Ready", true)
runtime.Parent = ReplicatedStorage
local registryThread = task.spawn(function()
    while not closed and registryEnabled do
        local success, err = pcall(function()
            registry:SetAsync(game.JobId, {placeId = game.PlaceId, players = #Players:GetPlayers(),
                capacity = Players.MaxPlayers, updated = os.time()}, config.ServerTTL, os.time())
        end)
        if not success and tostring(err) ~= registryError then
            registryError = tostring(err)
            warn("[Snow Hub] MemoryStore indisponível: " .. registryError)
        end
        task.wait(config.ServerHeartbeat)
    end
end)
local function shutdown()
    if closed then return end
    closed = true
    for _, c in ipairs(connections) do c:Disconnect() end
    if coroutine.status(registryThread) ~= "dead" then task.cancel(registryThread) end
    runtime:Destroy()
    if registryEnabled then pcall(function() registry:RemoveAsync(game.JobId) end) end
end
script.Destroying:Connect(shutdown)
game:BindToClose(shutdown)
