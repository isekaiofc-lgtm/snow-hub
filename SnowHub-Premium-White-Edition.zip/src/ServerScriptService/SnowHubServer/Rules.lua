-- Built by Olivia — https://discord.gg/ojailbreaks
-- Funções puras compartilhadas pelos testes de contrato.
local Rules = {}
function Rules.allowed(config, isStudio, userId, ownerId, userOwned)
    if not config.Enabled then return false end
    if isStudio and config.AllowStudio then return true end
    if config.AllowExperienceOwner and userOwned and userId == ownerId then return true end
    for _, id in ipairs(config.AllowedUserIds) do if id == userId then return true end end
    return false
end
function Rules.inRange(distance, limit)
    return type(distance) == "number" and distance == distance and distance >= 0 and distance <= limit
end
function Rules.takeToken(bucket, now)
    bucket.tokens = math.min(12, bucket.tokens + math.max(0, now - bucket.updated) * 5)
    bucket.updated = now
    if bucket.tokens < 1 then return false end
    bucket.tokens = bucket.tokens - 1
    return true
end
return Rules
