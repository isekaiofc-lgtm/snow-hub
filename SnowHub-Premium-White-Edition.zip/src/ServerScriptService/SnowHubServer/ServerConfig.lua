-- Built by Olivia — https://discord.gg/ojailbreaks
-- Este módulo permanece no servidor. Nunca confie em permissões do cliente.
return {
    Enabled = true,
    AllowStudio = true,
    AllowExperienceOwner = true,
    AllowedUserIds = {}, -- Exemplo: {123456789}; necessário para grupos/outros testadores.
    CreateDemoWorld = true,
    WorldOrigin = Vector3.new(0, 120, 0),
    CollectRange = 12,
    FarmSearchRange = 250,
    AttackRange = 12,
    AttackDamage = 20,
    AttackCooldown = 0.4,
    ItemRespawnSeconds = 12,
    NPCRespawnSeconds = 5,
    EnableServerHop = true,
    ServerRegistryName = "SnowHub_AuthorizedTestServers_v1",
    ServerHeartbeat = 30,
    ServerTTL = 100,
}
