-- Built by Olivia — https://discord.gg/ojailbreaks
local root = game:GetService("ReplicatedStorage"):WaitForChild("SnowHub", 15)
assert(root, "Pacote SnowHub não instalado.")
local modules = {Config = require(root.Config), Maid = require(root.Shared.Maid)}
for _, name in ipairs({"UI", "Network", "Farming", "Visual", "Combat", "Servers"}) do modules[name] = require(root.Client[name]) end
require(root.Client.App)(modules)
