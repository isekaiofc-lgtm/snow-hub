-- Built by Olivia — https://discord.gg/ojailbreaks
-- Execute no Command Bar do servidor: require(game.ServerScriptService.SnowHubServer.RulesSpec)()
return function()
    local Rules = require(game.ServerScriptService.SnowHubServer.Rules)
    local config = {Enabled = true, AllowStudio = true, AllowExperienceOwner = true, AllowedUserIds = {42}}
    local passed = 0
    local function check(name, condition)
        assert(condition, "Snow Hub: " .. name)
        passed = passed + 1
    end
    check("Studio autorizado", Rules.allowed(config, true, 7, 99, true))
    check("Dono autorizado", Rules.allowed(config, false, 99, 99, true))
    check("Allowlist autorizada", Rules.allowed(config, false, 42, 99, false))
    check("Outro jogador negado", not Rules.allowed(config, false, 7, 99, true))
    check("Grupo não concede acesso implícito", not Rules.allowed(config, false, 99, 99, false))
    config.Enabled = false
    check("Disabled revoga Studio", not Rules.allowed(config, true, 42, 99, true))
    config.Enabled = true
    config.AllowStudio = false
    check("Studio desabilitado nega desconhecido", not Rules.allowed(config, true, 7, 99, true))
    check("Limite inclusivo", Rules.inRange(12, 12))
    check("Fora do limite", not Rules.inRange(12.01, 12))
    check("Negativo rejeitado", not Rules.inRange(-1, 12))
    check("NaN rejeitado", not Rules.inRange(0 / 0, 12))
    check("Tipo incorreto rejeitado", not Rules.inRange("12", 12))
    local bucket = {tokens = 12, updated = 0}
    for _ = 1, 12 do check("Burst permitido", Rules.takeToken(bucket, 0)) end
    check("Burst excedido rejeitado", not Rules.takeToken(bucket, 0))
    check("Token reabastecido", Rules.takeToken(bucket, 0.2))
    check("Sem segundo token imediato", not Rules.takeToken(bucket, 0.2))
    print("[Snow Hub] " .. passed .. " verificações de contrato passaram.")
    return passed
end
