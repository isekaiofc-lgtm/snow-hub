"""Gera o cliente único, modelo do Studio, place de testes e ZIP, sem dependências."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile
import itertools

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'src'
OUT = ROOT / 'dist'
BASE_URL = 'https://raw.githubusercontent.com/isekaiofc-lgtm/snow-hub/main'
MODULE_ROOT = SRC / 'ReplicatedStorage' / 'SnowHub'
ATTRIBUTION = '-- Built by Olivia — https://discord.gg/ojailbreaks\n'
REFERENTS = itertools.count(1)

def read(path):
    return path.read_text(encoding='utf-8')

def bundle():
    sources = [('Config', MODULE_ROOT / 'Config.lua'), ('Maid', MODULE_ROOT / 'Shared' / 'Maid.lua')]
    sources += [(name, MODULE_ROOT / 'Client' / f'{name}.lua') for name in ['UI', 'Network', 'Farming', 'Visual', 'Combat', 'Servers', 'App']]
    chunks = [ATTRIBUTION, '-- Snow Hub: cliente único para ambiente preparado. Sem dependências remotas.\nlocal modules = {}\n']
    for name, path in sources:
        chunks.append(f'\n-- BEGIN {name}\nmodules.{name} = (function()\n{read(path)}\nend)()\n-- END {name}\n')
    chunks.append('\nreturn modules.App(modules)\n')
    result = ''.join(chunks)
    (OUT / 'snowhub.lua').write_text(result, encoding='utf-8')
    (OUT / 'loader.lua').write_text(f'loadstring(game:HttpGet("{BASE_URL}/snowhub.lua"))()\n', encoding='utf-8')
    return result

def node(parent, class_name, name, source=None):
    item = ET.SubElement(parent, 'Item', {'class': class_name, 'referent': f'RBX{next(REFERENTS):032X}'})
    props = ET.SubElement(item, 'Properties')
    ET.SubElement(props, 'string', {'name': 'Name'}).text = name
    if source is not None:
        ET.SubElement(props, 'ProtectedString', {'name': 'Source'}).text = source
    return item

def module_tree(parent, directory):
    for path in sorted(directory.iterdir()):
        if path.is_dir():
            module_tree(node(parent, 'Folder', path.name), path)
        elif path.suffix == '.lua':
            if path.name.endswith('.server.lua'):
                cls, name = 'Script', path.name[:-11]
            elif path.name.endswith('.client.lua'):
                cls, name = 'LocalScript', path.name[:-11]
            else:
                cls, name = 'ModuleScript', path.stem
            node(parent, cls, name, read(path))

def root_xml():
    root = ET.Element('roblox', {'version': '4'})
    ET.SubElement(root, 'External').text = 'null'
    ET.SubElement(root, 'External').text = 'nil'
    return root

def write_xml(path, root):
    ET.ElementTree(root).write(path, encoding='utf-8', xml_declaration=True)

def model_and_place():
    model = root_xml()
    package = node(model, 'Model', 'SnowHubPackage')
    replicated = node(package, 'Folder', 'ReplicatedStorage')
    module_tree(node(replicated, 'Folder', 'SnowHub'), MODULE_ROOT)
    server = node(node(package, 'Folder', 'ServerScriptService'), 'Folder', 'SnowHubServer')
    module_tree(server, SRC / 'ServerScriptService' / 'SnowHubServer')
    node(server, 'ModuleScript', 'RulesSpec', read(ROOT / 'tests' / 'Rules.spec.lua'))
    starter = node(node(package, 'Folder', 'StarterPlayerScripts'), 'LocalScript', 'SnowHub', read(SRC / 'StarterPlayer' / 'StarterPlayerScripts' / 'SnowHub.client.lua'))
    write_xml(OUT / 'SnowHubPackage.rbxmx', model)
    place = root_xml()
    node(place, 'Workspace', 'Workspace')
    rs = node(place, 'ReplicatedStorage', 'ReplicatedStorage')
    module_tree(node(rs, 'Folder', 'SnowHub'), MODULE_ROOT)
    ss = node(node(place, 'ServerScriptService', 'ServerScriptService'), 'Folder', 'SnowHubServer')
    module_tree(ss, SRC / 'ServerScriptService' / 'SnowHubServer')
    node(ss, 'ModuleScript', 'RulesSpec', read(ROOT / 'tests' / 'Rules.spec.lua'))
    sp = node(node(place, 'StarterPlayer', 'StarterPlayer'), 'StarterPlayerScripts', 'StarterPlayerScripts')
    node(sp, 'LocalScript', 'SnowHub', read(SRC / 'StarterPlayer' / 'StarterPlayerScripts' / 'SnowHub.client.lua'))
    # Testes de contrato executados automaticamente somente no place de demonstração.
    node(ss, 'Script', 'RunContractTests', 'if game:GetService("RunService"):IsStudio() then require(script.Parent.RulesSpec)() end')
    write_xml(OUT / 'SnowHubTestPlace.rbxlx', place)

def verify():
    files = list(SRC.rglob('*.lua')) + list((ROOT / 'tests').glob('*.lua'))
    assert len(files) == 15, f'Quantidade inesperada de fontes: {len(files)}'
    for path in files:
        content = read(path)
        assert content.strip(), path
        assert 'Built by Olivia' in content, path
        assert '\x00' not in content, path
    for name in ['SnowHubPackage.rbxmx', 'SnowHubTestPlace.rbxlx']:
        root = ET.parse(OUT / name).getroot()
        sources = root.findall('.//ProtectedString[@name="Source"]')
        assert len(sources) >= 15, (name, len(sources))
        for source in sources: assert source.text and source.text.strip()
    bundle_text = read(OUT / 'snowhub.lua')
    assert bundle_text.count('-- BEGIN ') == 9
    assert 'loadstring(' not in bundle_text and 'HttpGet(' not in bundle_text
    assert 'hookmetamethod' not in bundle_text and 'fireproximityprompt' not in bundle_text
    assert json.loads(read(ROOT / 'default.project.json'))['tree']['$className'] == 'DataModel'
    report = {'checks': 'passed', 'source_files': len(files), 'bundle_bytes': len(bundle_text.encode()),
              'sha256': hashlib.sha256(bundle_text.encode()).hexdigest(),
              'publication': {'status': 'published', 'url': BASE_URL + '/snowhub.lua'},
              'limits': ['Verificação estrutural/XML; não substitui execução no Roblox Studio e no Xeno.']}
    (OUT / 'build-report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=True))

def make_zip():
    target = OUT / 'SnowHub-Premium-White-Edition.zip'
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(ROOT.rglob('*')):
            if not path.is_file() or path == target or any(p in ['__pycache__', '.git'] for p in path.parts): continue
            archive.write(path, path.relative_to(ROOT))
    return target

def main():
    OUT.mkdir(exist_ok=True)
    bundle()
    model_and_place()
    verify()
    archive = make_zip()
    print('Pacote gerado:', archive)

if __name__ == '__main__': main()
